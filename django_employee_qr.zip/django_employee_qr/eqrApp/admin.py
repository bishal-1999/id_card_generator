from django.contrib import admin
from eqrApp import models

# Register your models here.
admin.site.register(models.Employee)

